#!/usr/bin/env python3
#-*- coding:utf-8 -*-


from flask import jsonify
from library.execptions import ValidationError
from . import api_1_0_blueprint as api

def bad_request(message):
    """400状态码的错误处理程序"""
    response = jsonify({'error': 'bad_request', 'message': message})
    response.status_code = 400
    return response

def unauthorized(message):
    """401状态码的错误处理程序"""
    response = jsonify({'error': 'unauthorized', 'message': message})
    response.status_code = 401
    return response

def forbidden(message):
    """403状态码的错误处理程序"""
    response = jsonify({'error': 'forbidden', 'message': message})
    response.status_code = 403
    return response

@api.errorhandler(ValidationError)
def validation_error(e):
    return bad_request(e.args[0])
