#!/usr/bin/env python3
#-*- coding:utf-8 -*-

from flask import g
from .errors import forbidden
from contextlib import wraps


def permission_required(permission):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kw):
            if not g.current_user.can(permission):
                return forbidden('Insufficient permissions')
            return f(*args, **kw)
        return decorated_function
    return decorator
