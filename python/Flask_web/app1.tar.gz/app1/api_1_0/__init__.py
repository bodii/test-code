#!/usr/bin/env python3
#-*- coding:utf-8 -*-

__all__ = [
    'api_1_0_blueprint',
    'authentication',
    'comments',
    'decorators',
    'errors',
    'posts',
    'users',
]

from flask import Blueprint

api_1_0_blueprint = Blueprint('api', __name__)

from . import (
                authentication, 
                posts,
                users,
                comments,
                errors,
            ) 
