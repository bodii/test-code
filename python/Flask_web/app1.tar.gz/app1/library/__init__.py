__all__ = [
    'mail',
    'avatar', # 头像
    'token',
    'userForm', # 用户表单
    'decorators', # 检查用户权限
    'postForm',  # 文章表单
    'commentForm',  # 评论表单
    ]
