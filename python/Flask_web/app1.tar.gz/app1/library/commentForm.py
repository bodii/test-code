#!/usr/bin/env python3
#-*- coding:utf-8 -*-


''' 用户评论form '''

from flask_wtf import FlaskForm
from wtforms import (
    StringField,
    PasswordField,
    BooleanField,
    SubmitField,
    TextAreaField,
    SelectField,
)
from wtforms.validators import (
    Required,
    Length,
    Email,
    Regexp,
    EqualTo,
)
from wtforms import ValidationError


class CommentForm(FlaskForm):
    body = StringField('', validators=[Required()])
    submit = SubmitField('Submit')
