#!/usr/bin/env python3
#-*- coding:utf-8 -*-


''' 错误处理 '''


class ValidationError(ValueError):
    pass