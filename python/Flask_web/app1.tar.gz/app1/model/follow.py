#!/usr/bin/env python3
#-*- coding:utf-8 -*-


''' 关注关联表模型 '''


from main import db
from datetime import datetime


class Follow(db.Model):
    ''' 关注关联表模型 '''
    __tablename__ = 'follows'
    follower_id = db.Column(
        db.Integer,
        db.ForeignKey('users.id'),
        primary_key=True,
    )
    followed_id = db.Column(
        db.Integer,
        db.ForeignKey('users.id'),
        primary_key=True,
    )
    timestamp = db.Column(db.DateTime, default=datetime.now)
