#!/usr/bin/env python3
#-*- coding:utf-8 -*-


''' 博客文章模型 '''

from main import db
from library.exceptions import ValidationError
from datetime import datetime

# 将文章的Markdown源文本保存的数据库中
from markdown import markdown
import bleach
from flask import url_for


class Post(db.Model):
    ''' 博客文章模型 '''
    __tablename__ = 'posts'
    id = db.Column(db.Integer, primary_key=True)
    body = db.Column(db.Text)
    timestamp = db.Column(db.DateTime, index=True, default=datetime.now)
    author_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    body_html = db.Column(db.Text)
    comments = db.relationship('Comment', backref='post', lazy='dynamic')

    @staticmethod
    def generate_fake(count=100):
        """生成虚拟博客文章"""
        from random import seed, randint
        from sqlalchemy.exc import IntegrityError
        import forgery_py

        seed()
        user_count = User.query.count()
        for i in range(count):
            u = User.query.offset(randint(0, user_count - 1)).first()
            p = Post(
                    body = forgery_py.lorem_ipsum.sentences(randint(1, 3)),
                    timestamp = forgery_py.date.date(True),
                    author = u,
                )
            db.session.add(self)
            db.session.commit()

    @staticmethod
    def on_changed_body(target, value, oldvalue, initiator):
        allowed_tags = [
                        'a', 'abbr', 'acronym', 'b', 'blockquote', 'code',
                        'em', 'i', 'li', 'ol', 'pre', 'strong', 'ul',
                        'h1', 'h2', 'h3', 'p',
                        ]
        target.body_html = bleach.linkify(bleach.clean(
                            markdown(value, output_format='html'),
                            tags=allowed_tags, strip=True
                        ))

    def to_json(self):
        """把文章转换成JSON格式"""
        json_post = {
            'url': url_for('api.get_post', id=self.id, _external=True),
            'body': self.body,
            'body_html': self.body_html,
            'timestamp': self.timestamp,
            'author': url_for('api.get_user', id=self.author_id, _external=True),
            'comments': url_for('api.get_post_comments', id=self.id, _external=True)
            'comment_count': self.comments.count()
        }
        return json_post
    
    @staticmethod
    def from_json(json_post):
        body = json_post.get('body')
        if body is None or body == '':
            raise ValidationError('post dose not have a body')
        return Post(body=body)

db.event.listen(Post.body, 'set', 'Post.on_changed_body')
