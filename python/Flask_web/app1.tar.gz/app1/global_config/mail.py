#!/usr/bin/env python3
# -*- coding:utf-8 -*-

class Config:
    
    FlASKY_MAIL_SUBJECT_PREFIX = '00'
    FLASKY_MAIL_SENDER = ''