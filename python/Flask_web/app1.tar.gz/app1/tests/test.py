#!/usr/bin/env python3
# -*- coding:utf-8 -*-

from global_config.app import default_config

print(default_config.BASE_DIR)