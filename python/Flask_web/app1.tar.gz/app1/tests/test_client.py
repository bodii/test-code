#!/usr/bin/env python3
#-*- coding:utf-8 -*-


''' 测试Web程序 '''

''' 使用Flask测试客户端编写的测试框架 '''

import unittest
from main import create_app, db
from model.user import User
from model.role import Role
from flask import url_for
import re

class FlaskClientTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app('testing')
        self.app_context = self.app.app_context()
        self.app_context.push()
        db.create_all()
        Role.insert_roles()
        self.client = self.app.test_client(use_cookies=True)

    def tearDown(self):
        db.session.remove()
        db.drop_all()
        self.app_context.pop()

    def test_home_page(self):
        """测试首页"""
        response = self.client.get(url_for('index.home'))
        self.assertTrue('Stranger' in response.get_data(as_text=True))
    
    def test_register_and_login(self):
        """测试注册和登录"""
        response = self.client.post(
            url_for('auth.register'),
            data = {
                'email': 'john@example.com',
                'username': 'john',
                'password': 'cat',
                'password': 'cat',
                },
            )
        self.assertTrue(response.status_code == 302)
        
        # 使用新注册的账户登录
        response = self.client.post(
            url_for('auth.login'),
            data = {
                'email': 'john@example.com',
                'password': 'cat',
                },
            follow_redirects = True,
            )
        data = response.get_data(as_text=True)
        self.assertTrue(re.search('Hello,\s+john!', data))
        self.assertTrue('You have not confirmed your account yet' in data)

        # 发送确认令牌
        user = User.query.filter_by(email='john@example.com').first()
        token = user.generate_confirmation_token()
        response = self.client.get(
            url_for('auth.confirm', token=token),
            follow_redirects = True,
            )
        data = response.get_data(as_text=True)
        self.assertTrue('You have confirmed your account' in data)

        # 退出
        response = self.client.get(
            url_for('auth.logout'),
            follow_redirects=True,
            )
        data = response.get_data(as_text=True)
        self.assertTrue('You have been logged out' in data)
